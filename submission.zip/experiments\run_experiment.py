import argparse
import random
import os

from config.config_loader import load_config
from config.config import AGV_MAX_BATTERY, MAP_SIZE, UAV_INIT_BATTERY, UAV_MAX_BATTERY, DEFAULT_SIMULATION_STEPS, MAX_SIMULATION_STEPS, RANDOM_SEED
from src.core.agv import AGV
from src.core.uav import UAV
from src.simulation.environment import Environment
from src.utils.simulator_helper import build_simulator


def run_experiment(
    experiment_name: str,
    num_uavs: int = 2,
    num_agvs: int = 2,
    num_tasks: int = 3,
    max_steps: int = DEFAULT_SIMULATION_STEPS,
    strategy_type: str = "baseline_direct",
    seed: int = RANDOM_SEED,
):
    """Run one simulation experiment with deterministic setup."""
    random.seed(seed)

    print(f"Running experiment: {experiment_name}")
    print(
        f"strategy={strategy_type}, seed={seed}, "
        f"uavs={num_uavs}, agvs={num_agvs}, tasks={num_tasks}, max_steps={max_steps}"
    )

    environment = Environment(map_size=MAP_SIZE)

    from src.utils.math_utils import generate_random_point

    for i in range(num_uavs):
        position = generate_random_point(MAP_SIZE)
        uav = UAV(i + 1, position)
        uav.battery = UAV_INIT_BATTERY
        environment.uavs.append(uav)

    for i in range(num_agvs):
        position = generate_random_point(MAP_SIZE)
        agv = AGV(i + 1, position)
        agv.charging_power = AGV_MAX_BATTERY * 2
        environment.agvs.append(agv)

    environment.generate_tasks(num_tasks, seed=seed)

    # 使用共享的构建仿真器函数
    simulator = build_simulator(environment, strategy_type)

    output_dir = simulator.run(max_steps=max_steps, experiment_name=experiment_name)
    print(f"Experiment completed. Results saved to: {output_dir}")
    return output_dir


def _build_arg_parser() -> argparse.ArgumentParser:

    parser = argparse.ArgumentParser(description="Run UAV-AGV experiment.")

    parser.add_argument("--config", help="Configuration file path")

    parser.add_argument("--experiment-name", default="default_experiment")

    parser.add_argument("--num-uavs", type=int, default=None)

    parser.add_argument("--num-agvs", type=int, default=None)

    parser.add_argument("--num-tasks", type=int, default=None)

    parser.add_argument("--max-steps", type=int, default=None)

    parser.add_argument(

        "--strategy",

        default=None,

        choices=["baseline_direct", "relay_coop", "energy_priority", "alns_unified"],

    )

    parser.add_argument("--seed", type=int, default=None)

    return parser


def main() -> None:

    parser = _build_arg_parser()

    args = parser.parse_args()


    # 从配置文件加载参数（如果提供）

    config = {}

    if args.config:

        config_path = args.config

        # 使用统一的配置加载器
        config = load_config(config_path)

        print(f"Loaded configuration from: {config_path}")


    # 命令行参数覆盖配置文件参数

    experiment_name = args.experiment_name or config.get('experiment_name', 'default_experiment')

    num_uavs = args.num_uavs if args.num_uavs is not None else config.get('num_uavs', 2)

    num_agvs = args.num_agvs if args.num_agvs is not None else config.get('num_agvs', 2)

    num_tasks = args.num_tasks if args.num_tasks is not None else config.get('num_tasks', 3)

    max_steps = args.max_steps if args.max_steps is not None else config.get('max_steps', DEFAULT_SIMULATION_STEPS)
    # 裁剪max_steps到最大限制
    max_steps = min(max_steps, MAX_SIMULATION_STEPS)

    strategy_type = args.strategy or config.get('strategy', 'baseline_direct')

    seed = args.seed if args.seed is not None else config.get('seed', RANDOM_SEED)


    run_experiment(

        experiment_name=experiment_name,

        num_uavs=num_uavs,

        num_agvs=num_agvs,

        num_tasks=num_tasks,

        max_steps=max_steps,

        strategy_type=strategy_type,

        seed=seed,

    )


if __name__ == "__main__":

    main()